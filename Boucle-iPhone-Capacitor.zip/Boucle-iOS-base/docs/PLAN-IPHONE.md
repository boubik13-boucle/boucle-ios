# Plan de migration iPhone — Boucle

## Ce qui est fait dans cette étape
- Copie de travail indépendante créée depuis l'archive Boucle V3.3 « choix musicaux ».
- Moteur `index.html` et banque `samples.js` copiés sans modification dans `www/`.
- Configuration initiale Capacitor créée (`appId`, nom, dossier web).
- Dépendances et commandes de préparation documentées.

## Ce qui n'est pas encore fait
- Le projet natif Xcode n'a pas encore été généré ni compilé.
- Aucun certificat Apple, profil de provisionnement ou compte développeur n'est configuré.
- Le microphone, l'import audio, le stockage et le comportement audio en arrière-plan ne sont pas encore certifiés sur iPhone.

## Étape suivante
Déposer ce projet dans un dépôt GitHub privé, puis le connecter à un service macOS de compilation (par exemple Codemagic). La compilation iOS et la distribution TestFlight nécessiteront ensuite la configuration du compte Apple Developer et de la signature.

## Règle de sécurité
Toujours conserver une archive ZIP de la dernière version connue comme fonctionnelle. Ne jamais déployer une version iOS tant que les tests de lecture, sauvegarde et import audio ne sont pas passés.
